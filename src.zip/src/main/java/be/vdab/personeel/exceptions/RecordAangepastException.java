package be.vdab.personeel.exceptions;

public class RecordAangepastException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
}
