package be.vdab.personeel.services;

import java.util.List;

import be.vdab.personeel.entities.Jobtitel;

public interface JobtitelService {
	List<Jobtitel>findAll();
}
